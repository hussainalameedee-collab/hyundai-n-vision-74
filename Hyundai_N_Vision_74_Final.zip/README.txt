HYUNDAI N VISION 74 — GRADE 9 ENGLISH PROJECT

To publish from an iPhone with GitHub Pages:
1. Download this ZIP and open it in the Files app. Tap the ZIP once to unzip.
2. Go to https://github.com and sign in.
3. Create a new PUBLIC repository named hyundai-n-vision-74.
4. In the repository, tap Add file -> Upload files.
5. Upload index.html and style.css from the unzipped folder, then commit.
6. Open Settings -> Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Choose branch main and folder /(root), then tap Save.
9. Wait a few minutes and copy the URL shown in Settings -> Pages.

The site is mobile-friendly. Photos and fonts load from external websites, so internet is required.
This is a student advertisement project, not an official Hyundai website. The N Vision 74 is a concept car.
